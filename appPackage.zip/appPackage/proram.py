import requests
import time
import sys
import socket
#response = requests.get("http://IP:PORT/getsensordata/"+sensorID1+/currentTemp)
# ip = '127.0.0.1'
# port = 5656
# sockfd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# sockfd.connect((ip, port))

st=time.time()
endtime = sys.argv[1]
et = st + float(endtime)
# print(st)
# print(et)
while st <= et:
    st=time.time()
    response = requests.get("http://IP:PORT/getSensorData/sensorID1/currentTemp")
    ct=response.text
    print("Current room temp: ",ct)
    # response = requests.get("http://IP:PORT/getSensorData/sensorID1/ACState")
    # print("Current AC state: ",response.text)
    response = requests.get("http://IP:PORT/getSensorData/sensorID1/ACTemp")
    print("Current AC temp: ",response.text)
    print()
    if int(ct)>40:
        print("Current room temperature is greater than 40, switch on the AC")
        response = requests.get("http://IP:PORT/changeControllerState/sensorID1/ACState/on")
        print("AC state changed successfully")
        print("Set new AC temperature to: 5")
        newTemp=5
        response = requests.get("http://IP:PORT/changeControllerState/sensorID1/ACTemp/"+str(newTemp))
        print("AC temperature set to "+str(newTemp)+"successfully!!!!!!!")
        print("__________________________________________________")
        response = requests.get("http://IP:PORT/getSensorData/sensorID1/currentTemp")
        ct=response.text
        print("Current room temp: ",ct)
    else:
        response = requests.get("http://IP:PORT/getSensorData/sensorID1/currentTemp")
        ct=response.text
        print("Current room temp: ",ct)
        print("Current room temperature is less than 40")
        print("_________________________________________________________")
        print()

        # sockfd.send("4".encode())
        # sys.exit()

# sockfd.send("4".encode())

#usermenu=123
#1 get current room temp
#2 change AC state //change controller state /ACstate
#3 set AC temp // /ACtemp

#switch
